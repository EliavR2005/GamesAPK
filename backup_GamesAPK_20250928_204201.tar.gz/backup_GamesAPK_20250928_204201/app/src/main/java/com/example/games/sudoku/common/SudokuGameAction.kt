package com.example.games.sudoku.common

enum class SudokuGameAction {
    PENCIL,    // ← En inglés
    NORMAL     // ← En inglés (era "Normal")
}
