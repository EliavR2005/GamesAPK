package com.example.games.sudoku.common

data class RemainingNumber(    // ← Nombre ORIGINAL
    val n: Int,
    val remaining: Int        // ← Original
)